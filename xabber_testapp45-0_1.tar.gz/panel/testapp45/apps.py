from django.apps import AppConfig


class TestPluginConfig(AppConfig):
    name = 'testapp45'
