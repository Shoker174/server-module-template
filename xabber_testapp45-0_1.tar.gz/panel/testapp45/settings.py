
MODULE_SPECS = [
    {
        'name': 'testapp45',
        'has_create': True,
        'menu_subitems': True,
    }
]