from django.db import models


class TestModel1(models.Model):
    pass


class TestModel2(models.Model):
    pass